#!/bin/bash
RUNID=$(date "+%Y.%m.%d.%H.%M.%S")
JARS=$(ls jars)
TESTCASES=$(ls testcases)

touch java.policy
mkdir -p jars
mkdir -p testcases
mkdir -p outputs/$RUNID
mkdir -p archives

for JAR in $JARS; do
  ID=${JAR%%.*}
  echo "Testing the program of student $ID ... $(date)"
  mkdir -p outputs/$RUNID/$ID
  for TESTCASE in $TESTCASES; do
    TESTNAME=${TESTCASE%%.*}
    echo $TESTCASE
    timeout 5s java -Djava.security.policy=java.policy -jar jars/$JAR < testcases/$TESTCASE 1> outputs/$RUNID/$ID/$TESTNAME.txt 2>> outputs/$RUNID/$ID/stderr.txt
  done
done

tar czvf archives/$RUNID.tar.gz test.sh outputs/$RUNID/ testcases/
